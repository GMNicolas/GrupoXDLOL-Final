# top-down-action-rpg-template
Top down action rpg template for Godot Engine

Demo: https://crimsonghostgames.com/elcaballerohueco/ (https is required for savegames to work)

Sound effects from freesound.org:
https://freesound.org/people/niamhd00145229/sounds/422709/
https://freesound.org/people/DDmyzik/sounds/460664/

Music by Aaron Krogh:
https://soundcloud.com/aaron-anderson-11/310-world-map-loop
https://soundcloud.com/aaron-anderson-11/sets/rpg-maker-music-loops
